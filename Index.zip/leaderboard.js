document.addEventListener("DOMContentLoaded", function () {
    let leaderboardContainer = document.getElementById("leaderboard-list");

    // Error handling kung wala ang leaderboard container
    if (!leaderboardContainer) {
        console.error("❌ Error: Leaderboard container not found. Check your HTML ID.");
        return;
    }

    leaderboardContainer.innerHTML = "";

    // Log localStorage data para makita kung may scores
    console.log("📊 Local Storage Data:", localStorage);

    let users = Object.keys(localStorage).filter(key => key.endsWith("_score"));

    if (users.length === 0) {
        leaderboardContainer.innerHTML = "<li>No scores available yet.</li>";
        return;
    }

    let leaderboard = users.map(userKey => {
        let username = userKey.replace("_score", "");
        let score = parseInt(localStorage.getItem(userKey)) || 0;
        return { username, score };
    });

    leaderboard.sort((a, b) => b.score - a.score);

    leaderboard.forEach(player => {
        let listItem = document.createElement("li");
        listItem.textContent = `${player.username}: ${player.score} points`;
        leaderboardContainer.appendChild(listItem);
    });

    console.log("✅ Leaderboard updated successfully!");
});